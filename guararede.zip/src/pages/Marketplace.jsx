
import React from 'react'

export default function Marketplace() {
  return <h1>Marketplace - Venda de Produtos</h1>
}
