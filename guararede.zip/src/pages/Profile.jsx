
import React from 'react'
import { useParams } from 'react-router-dom'

export default function Profile() {
  const { userId } = useParams()
  return <h1>Perfil do usuário {userId}</h1>
}
