
import React from 'react'

export default function Register() {
  return <h1>Cadastro - GuaraRede</h1>
}
