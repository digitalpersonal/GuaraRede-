
import React from 'react'

export default function Home() {
  return <h1>GuaraRede - Feed de Postagens</h1>
}
