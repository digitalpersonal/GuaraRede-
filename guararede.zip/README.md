# GuaraRede
Rede social com posts, grupos, marketplace e banners.

Funcionalidades:
- Login e cadastro
- Feed com fotos, vídeos, curtidas e comentários
- Perfis de usuário
- Grupos
- Marketplace
- Banners promocionais
- Backend com autenticação
- Layout responsivo

Configuração para deploy em Vercel incluída.